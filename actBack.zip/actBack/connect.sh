#! /bin/sh
res=$(hcitool scan | grep $1 | egrep -o "(..:){5}..")
#sudo rfcomm release rfcomm0
echo $res
sudo rfcomm bind $res rfcomm0
sudo hcitool cc $res
sudo service actSoft restart
