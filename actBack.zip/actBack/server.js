const Koa = require('koa')
const bodyParser = require('koa-bodyparser')
const fs = require('fs')
const app = new Koa()
const cors = require('koa-cors')
var exec = require('child-process-promise').exec;

var options = {
	origin: '*'
};

var test = {lol:"lolilol"};

app.use(cors(options));

app.use(bodyParser())

function constJSON(x) {
	return {
		factory: x[0],
		importance: x[1],
		area: x[2],
		serial: x[3],
		tagNumber: x[4],
		model: x[5],
		name: x[6]
	}
}

app.use( function* (next) {
	yield next;
	if (this.method == "POST") {
		console.log(this)
		const body = this.request.body
		console.log(body)
		 fs.writeFileSync('/home/pi/go/src/GoRPIsoft/act.conf', `${body.factory}\n${body.importance}\n${body.area}\n${body.serial}\n${body.tagNumber}\n${body.model}\n${body.name}`)

	//TODO exec => ERRORLEVEL => set status.
		var err = 0
		exec(`/home/pi/actBack/connect.sh ${body.serial}`).catch(err => {console.log(err)})
		this.body='lol'
		return
	} else {
		console.log(this)
		this.body='lolnon'
		if (this.accepts = 'json') (this.body = 'OK');

		// this.type="json"
		var lineReader = require('readline').createInterface({
  input: fs.createReadStream('/home/pi/go/src/GoRPIsoft/act.conf')
	});

		var x = []
		lineReader.on('line', function (line) {
			x.push(line);
		});
		yield function (cb) {lineReader.on("pause", cb)} ;
		var res = yield constJSON(x)
		console.log(res)
		this.body = res
	}
})

// Tell our app to listen on port 3000
app.listen(3001, function (err) {
  if (err) {
    throw err
  }
  console.log('Server started on port 3001')
})
