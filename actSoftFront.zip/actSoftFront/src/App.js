import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  withRouter
} from "react-router-dom";

import User from "./services/User";

import Login from "./components/Login";
import HomePage from "./components/Home";

const ConditionRoute = ({ condition, then, otherwise, ...rest }) => (
  <Route
    {...rest}
    render={props => {
      return condition ? React.createElement(then, props) : otherwise;
    }}
  />
);

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isAuthenticated: false,
      doneAuthenticationCheck: false,
      username: null
    };
    this.triggerAuthenticationCheck = this.triggerAuthenticationCheck.bind(
      this
    );
    this.signout = this.signout.bind(this);
  }

  triggerAuthenticationCheck(cb = () => {}) {
    User.isAuthenticated()
      .then(username => {
        if (username) {
          this.setState({
            isAuthenticated: true,
            doneAuthenticationCheck: true,
            username
          });
        } else {
          this.setState({
            isAuthenticated: false,
            doneAuthenticationCheck: true,
            username: null
          });
        }
      })
      .then(cb());
  }

  signout() {
    User.invalidate()
      .then(() => {
        this.setState({
          isAuthenticated: false,
          doneAuthenticationCheck: false,
          username: null
        });
      })
      .then(() => this.forceUpdate());
  }

  componentDidMount() {
    this.triggerAuthenticationCheck();
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      prevState.isAuthenticated !== this.state.isAuthenticated &&
      this.state.doneAuthenticationCheck !== prevState.doneAuthenticationCheck
    ) {
      this.triggerAuthenticationCheck();
    }
  }

  render() {
    const { isAuthenticated, doneAuthenticationCheck } = this.state;
    if (doneAuthenticationCheck) {
      return (
        <Router>
          <div style={{ height: "100%" }}>
            <ConditionRoute
              path="/login"
              condition={!isAuthenticated}
              then={withRouter(() => (
                <Login
                  triggerAuthenticationCheck={this.triggerAuthenticationCheck}
                />
              ))}
              otherwise={
                (
                  <Redirect
                    to={{
                      pathname: "/",
                      state: { from: this.props.location }
                    }}
                  />
                )
              }
            />
            <ConditionRoute
              exact
              path="/"
              condition={isAuthenticated}
              then={() => <HomePage signout={this.signout} />}
              otherwise={
                (
                  <Redirect
                    to={{
                      pathname: "/login",
                      state: { from: this.props.location }
                    }}
                  />
                )
              }
            />
          </div>
        </Router>
      );
    }
    return <p>Loading...</p>;
  }
}

export default App;
