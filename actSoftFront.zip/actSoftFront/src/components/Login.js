import React, { Component } from "react";
import { Form, Input, Button, Checkbox } from "antd";
import styled from "styled-components";
import User from "../services/User";
import { withRouter } from "react-router-dom";

const FormItem = Form.Item;

const StyledForm = styled(Form)`
    display: flex;
    flex-direction: column;
`;

const WhiteCheckbox = styled(Checkbox)`
    color: #f2f2f2;
`;

const Box = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
    background-color: #1d2763;
`;

const Title = styled.h1`
    color: whitesmoke;
    margin-bottom: 20px;
`;

const ErrorMessage = styled.p`
    opacity: ${({ showError }) => showError ? "1" : "0"};
    color: red;
`;

class NormalLoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      validInput: true
    };
  }

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const { username, password } = values;
        User.authenticate(username, password)
          .then(() => {
            this.props.triggerAuthenticationCheck(() => this.props.push("/"));
          })
          .catch(() => this.setState({ validInput: false }));
      }
    });
  };

  resetError = () => {
    if (!this.state.validInput) {
      this.setState({ validInput: true });
    }
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <StyledForm
        onSubmit={this.handleSubmit}
        className="login-form"
        onChange={this.resetError}
      >
        <FormItem>
          {getFieldDecorator("username", {
            rules: [{ required: true, message: "Please input your username!" }]
          })(
            <Input placeholder="Username" />
          )}
        </FormItem>
        <FormItem>
          {getFieldDecorator("password", {
            rules: [{ required: true, message: "Please input your password!" }]
          })(
             <Input type="password"
              placeholder="Password"
            />
          )}
        </FormItem>
        <ErrorMessage showError={!this.state.validInput}>
          Error in username or password
        </ErrorMessage>
        <FormItem>
          {getFieldDecorator("remember", {
            valuePropName: "checked",
            initialValue: true
          })(<WhiteCheckbox>Remember me</WhiteCheckbox>)}
        </FormItem>
        <Button type="primary" htmlType="submit" className="login-form-button">
          Log in
        </Button>
      </StyledForm>
    );
  }
}

const WrappedNormalLoginForm = withRouter(Form.create()(NormalLoginForm));

const Login = ({ triggerAuthenticationCheck }) => (
  <Box>
    <div>
      <Title>Bernard Controls</Title>
      <WrappedNormalLoginForm
        triggerAuthenticationCheck={triggerAuthenticationCheck}
      />
    </div>
  </Box>
);

export default Login;
