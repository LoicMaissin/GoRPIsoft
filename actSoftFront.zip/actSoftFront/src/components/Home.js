import React, { Component } from "react";
import "antd";
import styled from "styled-components";
import { Layout, Menu } from "antd";
import WrappedConfigForm from "./configForm"

const Item = Menu.Item;

const { Sider } = Layout;

const ImgStyled = styled.img`
  height: 32px;
`;

const CustomLayout = styled(Layout)`
  min-height: 100%;
`;

const Logo = styled.div`
  height: 32px;
  border-radius: 6px;
  margin: 12px;
`;
const SignOut = styled(Item)`
  background-color: #cb3837;
`;
const Title = styled.div`
  font-size: 14px;
  color: #fff;
  display: flex;
  align-items:center;
`;
const SpanTitle = styled.span`
  margin-left: 16px;
`;

class HomePage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: true
    };
  }

  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed
    });
  };

  render() {
    return (
      <CustomLayout>
        <Sider trigger={null} collapsible collapsed={this.state.collapsed}>
          <Logo>
            <Title>
              <ImgStyled src="/bernard-icon.png" role="presentation" />
              <SpanTitle hidden={this.state.collapsed}>
                {" "}Bernard Controls{" "}
              </SpanTitle>
            </Title>
          </Logo>
          <Menu theme="dark" mode="inline" defaultSelectedKeys={["1"]}>
            <SignOut key="4">
              <div onClick={this.props.signout}>
                
                <span className="nav-text">
                  Sign Out
                </span>
              </div>
            </SignOut>
          </Menu>
        </Sider>
        <Layout>
          <WrappedConfigForm/>
        </Layout>
      </CustomLayout>
    );
  }
}

export default HomePage;
