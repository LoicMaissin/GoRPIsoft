import React, { Component } from "react";
import { Form, Input, Button, Radio, notification } from 'antd';
//import fetchJsonp from 'fetch-jsonp';
import styled from "styled-components";

const FormItem = Form.Item;

const TitleConfig = styled.h1`
  text-align: center;
  margin-top: 25px
`;

const openNotificationWithIcon = (type, title, text) => {
  notification.open({
    message: title,
    description: text,
    duration: 8,
  });
}

/// PO DU TOUT, a mettre dans componentDidMount pour ensuite setState


class ConfigForm extends Component {
  state = {
    confirmDirty: false,
  };
  componentDidMount() {
    var myInit = { method: 'GET',
                 headers: {'accepts':'json'},
                 mode: 'cors',
                 cache: 'default',
                 timeout: 0}
    fetch('http://10.198.24.108:3001', myInit).then(res => {
      return res.json()}).then(init => {
        //console.log(init)
        this.props.form.setFieldsValue(init)
      })

  }
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        fetch("http://10.198.24.108:3001", {
  method: 'post',
  headers: {
  "Access-Control-Allow-Origin": "*",
  'Accept': 'application/json, application/xml, text/plain, text/html, *.*',
  'Content-Type': 'application/json; charset=utf-8'
  },
  body: JSON.stringify(values)
}).then(res => {
  console.log(res)
    if (res.status !== 200) {
      openNotificationWithIcon("warning", "An error occurred", res.statusText)
    } else {
      openNotificationWithIcon('success', 'Success !', "Configuration saved")
    }
});
}})}

  handleConfirmBlur = (e) => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  }
  checkPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  }
  checkConfirm = (rule, value, callback) => {
    const form = this.props.form;
    if (value && this.state.confirmDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        span: 14,
        offset: 6,
      },
    };
    return (
      <Form onSubmit={this.handleSubmit}>
      <TitleConfig> Configuration Menu </TitleConfig>
      <br />
      <FormItem
        {...formItemLayout}
        label={("Factory")}
      >
        {getFieldDecorator('factory', {})(
          <Input />
        )}
      </FormItem>
      <FormItem
        {...formItemLayout}
        label="Actuator importance"
      >
        {getFieldDecorator('importance', {
          rules: [
            { required: true, message: 'Please select the actuator importance!' },
          ],
        })(
          <Radio.Group>
            <Radio.Button value="0">Very Low</Radio.Button>
            <Radio.Button value="1">Low</Radio.Button>
            <Radio.Button value="2">Medium</Radio.Button>
            <Radio.Button value="3">High</Radio.Button>
            <Radio.Button value="4">Very High</Radio.Button>
          </Radio.Group>
        )}
      </FormItem>
        <FormItem
          {...formItemLayout}
          label="Actuator area"
        >
          {getFieldDecorator('area', {
            rules: [{
              required: true, message: "Please input the actuator's area!",
            }],
          })(
            <Input type="area" onBlur={this.handleConfirmBlur} />
          )}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={("Serial Number")}
        >
          {getFieldDecorator('serial', {
            rules: [{ required: true, message: "Please input the actuator' serial number!" }],
          })(
            <Input />
          )}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={("Tag Number")}
        >
          {getFieldDecorator('tagNumber', {})(
            <Input />
          )}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={("Actuator name")}
        >
          {getFieldDecorator('name', {})(
            <Input />
          )}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={("Actuator Model")}
        >
          {getFieldDecorator('model', {})(
            <Input />
          )}
        </FormItem>
        <FormItem {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit" size="large">Submit</Button>
        </FormItem>
      </Form>
    );
  }
}

const WrappedConfigForm = Form.create()(ConfigForm);
export default WrappedConfigForm;
