const AUTHENTICATED = "authenticated";
const USERNAME = "username";

class User {
  static isAuthenticated() {
    return Promise.resolve(
      localStorage.getItem(AUTHENTICATED) === "true" &&
        localStorage.getItem(USERNAME)
    );
  }

  static authenticate(username, password) {
    // Verify user info
    if (username === "admin" && password === "password") {
      localStorage.setItem(AUTHENTICATED, "true");
      localStorage.setItem(USERNAME, username);
      return Promise.resolve();
    } else {
      return Promise.reject("Authentication Failed");
    }
  }

  static invalidate() {
    return Promise.resolve(
      localStorage.setItem(AUTHENTICATED, null)
    ).then(() => {
      return Promise.resolve(localStorage.setItem(USERNAME, null));
    });
  }
}

export default User;
